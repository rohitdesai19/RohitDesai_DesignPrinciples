package Assignment2;

public class Operations {
	static int addition(double a,double b) {
		int a1=(int)a,b1=(int)b;
		return (a1+b1);
	}
	
	static int subtraction(double a,double b) {
		int a1=(int)a,b1=(int)b;
		return (a1-b1);
	}
	
	static int multiplication(double a,double b) {
		int a1=(int)a,b1=(int)b;
		return (a1*b1);
	}
	
	static int division(double a,double b) {
		int a1=(int)a,b1=(int)b;
		return (a1/b1);
	}
}
